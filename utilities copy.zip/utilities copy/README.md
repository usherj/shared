# Utilities for OpenAPI Spec

## Overview
The Utilities project provides OpenAPI code generators which allow developers to generate code in a service implementation repository based on the OpenAPI contract.

## Contract Lifecycle

Contract Lifecycle Diagram

![Contract Lifecycle Diagram](/media/contract-lifecycle-v2.jpg "Contract Lifecycle")
  

## Generators
- gs-spring - [documentation](./gs-spring-openapi-generator/README.md)
- gscloud-spring - [documentation](./gscloud-spring-openapi-generator/README.md)
- gs-avro-idl - [documentation](./gs-avro-idl-openapi-generator/README.md)
