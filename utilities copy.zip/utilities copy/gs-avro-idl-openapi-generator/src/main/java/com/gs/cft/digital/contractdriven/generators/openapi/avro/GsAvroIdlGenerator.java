package com.gs.cft.digital.contractdriven.generators.openapi.avro;

import io.swagger.v3.oas.models.media.ComposedSchema;
import io.swagger.v3.oas.models.media.Schema;
import org.openapitools.codegen.CodegenConfig;
import org.openapitools.codegen.CodegenModel;
import org.openapitools.codegen.CodegenProperty;
import org.openapitools.codegen.languages.AvroSchemaCodegen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class GsAvroIdlGenerator extends AvroSchemaCodegen implements CodegenConfig {

    public static final String OUTPUT_NAME = "outputFile";
    private static String sModelPackage = "model";
    private static final Logger LOGGER = LoggerFactory.getLogger(GsAvroIdlGenerator.class);

    public String getName() {
        return "gs-avro-idl";
    }


    /**
     * Returns human-friendly help for the generator.  Provide the consumer with help
     * tips, parameters here
     *
     * @return A string value for the help message
     */
    public String getHelp() {
        return "Generates a gs-avro-idl client library.";
    }

    @Override
    public Map<String, Object> postProcessModels(Map<String, Object> objs) {
        Map<String, Object> pobjs = super.postProcessModels(objs);
        List<Object> models = (List<Object>) objs.get("models");
        Pattern pattern = Pattern.compile("(\\w+)(?=,|$)");

        for (Object _mo : models) {
            Map<String, Object> mo = (Map<String, Object>) _mo;
            CodegenModel cm = (CodegenModel) mo.get("model");
            cm.imports.remove("array");
            cm.imports.remove("map");
            cm.imports.remove("AnyType");
            cm.imports.remove("object");

            cm.imports = cm.imports.stream().map(i -> {
                        Matcher m = pattern.matcher(i);
                        List<String> modelImports = new ArrayList<>();
                        while (m.find()) {
                            modelImports.add(m.group());
                        }
                        return modelImports;
                    }
            ).flatMap(s -> s.stream() ).collect(Collectors.toSet());

// when we move to Java at least 9...
//            cm.imports = cm.imports.stream().map(i -> Pattern.compile("(\\w+)(?=,|$)").matcher(i)
//                          .results()
//                          .map(MatchResult::group).collect(Collectors.toList())
//
//            ).flatMap(s -> s.stream() ).collect(Collectors.toSet());
        }
        return pobjs;
    }

    @Override
    public CodegenProperty fromProperty(String name, Schema p) {
        CodegenProperty cp =  super.fromProperty(name, p);
        if (p instanceof ComposedSchema) { // composed schema
            ComposedSchema cs = (ComposedSchema) p;
            if (cs.getOneOf() != null && !cs.getOneOf().isEmpty()) {
                cp.isInherited = true;
            }
        }
        return cp;
    }

    @SuppressWarnings("static-method")
    public String toOneOfName(List<String> names, ComposedSchema composedSchema) {
        names = names.stream().map(n -> sModelPackage + "." + n).collect(Collectors.toList());
        return String.join(", ", names);
    }
    @Override
    public void processOpts() {
        super.processOpts();
        sModelPackage = modelPackage;
    }

    public GsAvroIdlGenerator() {
        super();

        modelTemplateFiles.put("model.mustache", ".avdl");
        // set the output folder here
        skipOverwrite = true;
        outputFolder = "generated-code/gs-avro-idl";
        embeddedTemplateDir = templateDir = "gs-avro-idl";
        sModelPackage = modelPackage;
    }
}
