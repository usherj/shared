# OpenAPI Generator for Avro Messaging models

## Overview
This is a boiler-plate project to help you get started with your own with an OpenAPI specification. 

This project is a template and framework to apply your own implementation and business logic for your service.

## Contributing

All are welcome to contribute to this project and should consult with [Daniel Kuras](mailto:Daniel.Kuras@ln.email.gs.com).


## About OpenAPI
OpenAPI defines a standard, language-agnostic interface for REST APIs which allows both humans and computers to discover and understand the capabilities of the service without access to source code, documentation, or network traffic inspection.
When properly described with OpenAPI, a consumer can understand and interact with the remote service with a minimal amount of implementation logic. OpenAPI removes the guesswork in calling the service.

Review the [OpenAPI-Spec](https://github.com/OAI/OpenAPI-Specification) for additional information about the OpenAPI project, additional libraries with language support and more. 

## About Avro - Generator name: "gs-avro-idl"

Avro defines a standard, language-agnostic interface for messaging which allows both humans and computers to discover and understand messaging communication model without access to source code, documentation, or network traffic inspection.
Avro provides humar readable schema to define communication model structure and a code generator which converts Avro schema to programming language code.
Avro offers to types of schema definitions:
- low level - avsc - http://avro.apache.org/docs/1.9.2/spec.html
- **high level - avdl - https://avro.apache.org/docs/current/idl.html**

## Working with the Avro OpenAPI Generator

The openAPI generator converts openAPI component models to Avro IDL (high leve schema):
*
1. To configure end-to-end code generation, (_OpenAPI Yaml -> Avro IDL Schema -> Java code_) refer to the [Parent Pom](https://gitlab.aws.site.gs.com/marcus/api/parent-poms/-/blob/master/README.md) documentation.
2. Use the reference below to ensure values are properly defined in OpenAPI before conversion.


# Avro IDL Generator Conversion Details

Use the reference below to see the syntax required in OpenAPI and what the expected end-to-end conversion will look like in `Avro IDL` and `Java`.


## Standard types

### String

_OpenApi:_ 
```
name:
    type: string
```

_Avro IDL:_ 

```string name;```

_Java:_

```private java.lang.String name;```

### Date

_OpenApi:_ 
```
dob:
    type: string
    format: date
```

_Avro IDL:_ 

```date dob;```

_Java:_

```private java.time.LocalDate dob;```

### Date-time

_OpenApi:_ 
```
createdAt:
    type: string
    format: date-time
```

_Avro IDL:_ 

```timestamp_ms createdAt;```

_Java:_

```private java.time.Instant createdAt;```

### BigDecimal

_OpenApi:_ 
```
aer:
    type: number
    format: double
```

_Avro IDL:_ 

```@java-class("java.math.BigDecimal") string aer;```

_Java:_

```private java.math.BigDecimal aer;```

### Long

_OpenApi:_ 
```
unixTimestamp:
    type: integer
    format: int64
```

_Avro IDL:_ 

```long unixTimestamp;```

_Java:_

```private long unixTimestamp;```

### int

_OpenApi:_ 
```
age:
    type: integer
    format: int32
```

_Avro IDL:_ 

```int age;```

_Java:_

```private int age;```

### float

_OpenApi:_ 
```
size:
    type: number
    format: float
```

_Avro IDL:_ 

```float size;```

_Java:_

```private float size;```

## Complex Types

## Arrays

### Array of string

_OpenApi:_ 
```
names:
    type: array
    items:
        type: string
```

_Avro IDL:_ 

```array<string> names;```

_Java:_

```private List<string> names;```

### Array of complex objects

_OpenApi:_ 
```
animals:
    type: array
    items:
        $ref: '#/components/schemas/Animal'
```

_Avro IDL:_ 

```array<Animal> animals;```

_Java:_

```private List<Animal> animals;```

# Maps

### Map of primitive types

_OpenApi:_ 
```
# define inline field as map of value type being string (primitive type)
langLabels:
    additionalProperties:
        type: string

----- or -----

#Create map fo string type 
StringMap:
    additionalProperties:
        type: string

#Define field type as created map type
langLabels:
    $ref: '#/components/schemas/StringMap'
```

_Avro IDL:_ 

```map<string> langLabels;```

_Java:_

```private Map<java.lang.String, ava.lang.String> langLabels;```

### map of models

_OpenApi:_ 
```
#model
Animal:
    properties:
        animalId:
            type: string
            format: uuid
        name:
            type: string

--------------

# define inline field as map of value type of created model 
ownersAnimals:
    additionalProperties:
        $ref: '#/components/schemas/Animal'

----- or -----

#define map as map type with value type as Animal 
OwersAnimals:
    additionalProperties:
        $ref: '#/components/schemas/Animal'

#define field type as created map type
langLabels:
    $ref: '#/components/schemas/OwersAnimals'
```

_Avro IDL:_ 

```map<Animal> ownersAnimals;```

_Java:_

```private Map<ava.lang.String, Animal> ownersAnimals;```

### map of object (supports embeded map of maps)

_OpenApi:_ 
```

#define field type as generic map type
templateData:
   additionalProperties: {}
```

_Avro IDL:_ 

```map<union {string,map<string>}> templateData;```

_Java:_

```private java.util.Map<java.lang.String, java.lang.Object> templateData```

## Optional fields
Nullable can be used to define optional fields. To mark field as optional it needs to be defined as ```nullable: true ```

_OpenApi:_ 
```
name:
    type: string
    nullable: true

age:
    type: integer
    format: int32
    nullable: true

dob:
    type: string
    format: date
    nullable: true

aer:
    type: number
    format: double
    nullable: true

animal:
    allOf:
        - $ref: '#/components/schemas/Animal'
    nullable: true

names:
    type: array
    items:
        type: string
    nullable: true

ownersAnimals:
    additionalProperties:
        $ref: '#/components/schemas/Animal'
    nullable: true

templateData:
    additionalProperties: {}
    nullable: true

-----------------

#supporting model
Animal:
    properties:
        animalId:
            type: string
            format: uuid
        name:
            type: string
```

_Avro IDL:_ 

```
union {null, string} name = null;
union {null, int} age = null;
union {null, date} dob = null;
union {null, @java-class("java.math.BigDecimal") string} aer = null;
union {null, Animal} animal = null;
union {null, array<string>} names = null;
union {null, map<Animal>} ownersAnimals = null;
union {null, map<union {string,map<string>}>} templateData = null;
```

_Java:_

```
private java.lang.String name;
private int name;
private java.time.LocalDate dob;
private java.math.BigDecimal aer;
private Animal animal;
private List<string> names;
private Map<ava.lang.String, Animal> ownersAnimals;
private java.util.Map<java.lang.String, java.lang.Object> templateData;
```

## Inheritance
Avro does not support inheritance but by using composition (sort of) and union it is possible to create models which contains own "extended" fields and fields from super class

_OpenApi:_ 
```
AnimalType:
    type: string
    enum:
        - CAT
        - DOG
Animal:
    required:
        - animalType
    properties:
        animalType:
            $ref: '#/components/schemas/AnimalType'
        animalId:
            type: string
            format: uuid
        name:
            type: string
        owner:
            type: string
            nullable: true

Dog:
    allOf:
        - $ref: '#/components/schemas/Animal'
        - type: object
          properties:
            bark:
              type: string

Cat:
    allOf:
        - $ref: '#/components/schemas/Animal'
        - type: object
          properties:
            miau:
              type: string

Zoo:
    properties:
        animals:
            type: array
            items:
                oneOf:
                    - $ref: '#/components/schemas/Cat'
                    - $ref: '#/components/schemas/Dog'

Owner:
    properties:
        animal:
            oneOf:
                - $ref: '#/components/schemas/Cat'
                - $ref: '#/components/schemas/Dog'
            nullable: true


```

_Avro IDL:_ 

```
------ Cat.avdl
@namespace("")

protocol CatProtocol {

    import idl "./Animal.avdl";
    import idl "./AnimalType.avdl";

    record Cat {
         AnimalType animalType;
         string animalId;
         string name;
         union {null, string} owner = null;
         string miau;
    }
}

------ Dog.avdl
@namespace("")

protocol DogProtocol {

    import idl "./Animal.avdl";
    import idl "./AnimalType.avdl";

    record Dog {
         AnimalType animalType;
         string animalId;
         string name;
         union {null, string} owner = null;
         string bark;
    }
}

------ Owner.avdl
@namespace("")

protocol OwnerProtocol {

    import idl "./Cat.avdl";
    import idl "./Dog.avdl";

    record Owner {
         union { null ,Cat, Dog} animal = null;
    }
}

------ Zoo.avdl
@namespace("")

protocol ZooProtocol {

    import idl "./Cat.avdl";
    import idl "./Dog.avdl";

    record Zoo {
         array<union { Cat, Dog } > animals;
    }
}
```

_Java:_

```
#Java files have been truncated and only shows list of fields with types
------ Cat.java
public class Cat extends org.apache.avro.specific.SpecificRecordBase {
    private model.AnimalType animalType;
    private java.lang.String animalId;
    private java.lang.String name;
    private java.lang.String owner;
    private java.lang.String miau;
}

------ Dog.java
public class Cat extends org.apache.avro.specific.SpecificRecordBase {
    private model.AnimalType animalType;
    private java.lang.String animalId;
    private java.lang.String name;
    private java.lang.String owner;
    private java.lang.String bark;
}
------ Owner.java
public class Owner extends org.apache.avro.specific.SpecificRecordBase {
    private java.lang.Object animal;
}

------ Zoo.java
public class Cat extends org.apache.avro.specific.SpecificRecordBase {
    private java.util.List<java.lang.Object> animals;
}
```

