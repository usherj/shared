package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.OpenAPIFactory;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.media.ComposedSchema;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;

import java.util.List;
import java.util.Map;

public class ScanObjectPropertiesAction implements Action {
    private static final String[] VALID_TYPES = new String[]{
            "array",
            "boolean",
            "integer",
            "number",
            "object",
            "null",
            "string"
    };

    private static final String[] STRING_FORMATS = new String[] {
            "uuid",
            "binary",
            "date-time",
            "date",
            "byte",
            "email",
            "password"
    };

    private static final String[] NUMBER_FORMATS = new String[]{
            "float",
            "double"
    };

    private static final String[] INTEGER_FORMATS = new String[] {
            "int32",
            "int64"
    };

    public static ApiResult execute(ApiResult result) {
        if (result.getFilename().toString().contains("avro") || !result.isVersionMatch()) {
            return result;
        }

        scanParameters(result.getApi().getComponents().getParameters());
        scanPathProperties(result.getApi().getPaths());
        scanObjectProperties(result.getApi().getComponents().getSchemas());

        return result;
    }

    private static void scanParameters(Map<String, Parameter> parameters) {
        if (parameters != null) {
            parameters.forEach((s, parameter) -> {
                Schema schema = parameter.getSchema();
                schema.setNullable(null);
                verifyList(schema, "parameter: " + s);
            });
        }
    }

    private static void scanPathProperties(io.swagger.v3.oas.models.Paths paths) {
        paths.forEach((pathName, pathItem) -> {
                List<Operation> operations = OpenAPIFactory.getOperations(pathItem);
                if (operations != null) {
                    operations.forEach(operation -> {
                        List<Parameter> parameters = operation.getParameters();
                        if (parameters != null) {
                            parameters.forEach(parameter -> {
                                Schema schema = parameter.getSchema();
                                schema.setNullable(null);
                                verifyList(schema, "parameter: " + parameter.getName());
                            });
                        }
                    });
                }
            });
        }

    private static void scanObjectProperties(Map<String, Schema> schemas) {
        schemas.forEach((objectName, object) -> {
            object.setNullable(null);
            String type = object.getType();

            if (type == null && object.getProperties() != null) {
                throw new RuntimeException(String.format("Error: Object not defined with type: object See: %s Object", objectName));
            }
            if (type == null) { // AllOfs?
                ComposedSchema composedSchema = (ComposedSchema) object;
                List<Schema> allOf = composedSchema.getAllOf();
                allOf.forEach(schema -> {
                    schema.setNullable(null);
                    String allOfType = schema.getType();
                    if (allOfType != null && allOfType.equalsIgnoreCase("object")) {
                        scanProperties(schema.getProperties());
                    }
                });
            } else {
//            if (type.equalsIgnoreCase("object")) {
                scanProperties(object.getProperties());
            }
        });
    }

    private static void scanProperties(Map<String, Schema> properties) {
        if (properties != null) {
            properties.forEach((s, property) -> {
                property.setNullable(null);
                if (property.getType() != null || property.getFormat() != null) {
                    verifyList(property, "property: " + s);
                }
            });
        }
    }

    private static void verifyList(Schema schema, String source) {
        String type = schema.getType();
        String format = schema.getFormat();

        String $ref = schema.get$ref();

        if ($ref != null && type == null) { // object has a ref ignore
            return;
        }

        if (!verifyListItems(type, VALID_TYPES)) {
            throw new RuntimeException(String.format("Error: Invalid type: '%s' used in %s ", type, source));
        }

        if (format == null) {
            return;
        }

        boolean isValid = false;
        switch (type.toLowerCase()) {
            case "string":
                isValid = verifyListItems(format, STRING_FORMATS);
                break;
            case "integer":
                isValid = verifyListItems(format, INTEGER_FORMATS);
                break;
            case "number":
                isValid = verifyListItems(format, NUMBER_FORMATS);
                break;
        }
        if (isValid == false) {
            throw new RuntimeException(String.format("Error: Invalid usage: type: '%s', format: %s used in %s ", type, format, source));
        }
    }

    private static boolean verifyListItems(String format, String[] list) {
        for (int i = 0; i < list.length; i++) {
            if (list[i].equalsIgnoreCase(format)) {
                return true;
            }
        }
        return false;
    }
}
