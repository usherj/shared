package com.gs.cft.contracts.generator.mojos;

import com.gs.cft.contracts.generator.CommonConstants;
import com.gs.cft.contracts.generator.models.ApiResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

abstract class AbstractApiGenMojo extends AbstractMojo {
    Path projectBaseDirectory;

    @Parameter(required = true)
    String contractsDirectory;

    @Parameter(required = true)
    String targetDirectory;

    @Parameter(required = false)
    String[] excludes = new String[] {"*"};

    @Parameter(required = false)
    String[] includes = new String[] {"*"};

    void setParams() {
        Path contractsPath = Paths.get(contractsDirectory).normalize();

// find base path based on PROJECT_ROOT_DIR node name.
        int parentNode = 0;
        for (int i = 0; i < contractsPath.getNameCount(); i++) {
            String pathNode = contractsPath.getName(i).toString();
            if (pathNode.equalsIgnoreCase(CommonConstants.PROJECT_ROOT_DIR)) {
                parentNode = i + 1;
            }
        }
        if (parentNode > 0) {
            Path subpath = contractsPath.subpath(0, parentNode);
            projectBaseDirectory = contractsPath.getRoot().resolve(subpath);
            contractsDirectory = projectBaseDirectory.relativize(contractsPath).toString();
        } else {
            throw new RuntimeException(String.format("Error: Contract directory %s does not have base directory %s", contractsDirectory, CommonConstants.PROJECT_ROOT_DIR));
        }

        for (int i = 0; i < includes.length; i++) {
            includes[i] = includes[i].replace("\\", "/").replace("/", File.separator);
        }
        for (int i = 0; i < excludes.length; i++) {
            excludes[i] = excludes[i].replace("\\", "/").replace("/", File.separator);
        }
    }

    void logHeader(String goal) {
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
        getLog().info("Maven mojo   goal: " + goal);
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
        getLog().info("projectBaseDirectory: " + projectBaseDirectory);
        String contractsDirectory = this.contractsDirectory;
        if (contractsDirectory.length() == 0  || contractsDirectory == null) {
            contractsDirectory = "/";
        }
        getLog().info("contractsDirectory: " + contractsDirectory);
    }

    void logFilterParams() {
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
        for (String s:includes) {
            getLog().info("Includes: " + s);
        }
        for (String s:excludes) {
            getLog().info("Excludes: " + s);
        }

        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
    }

    ApiResult logResult(ApiResult result) {
        result.setEndTime(System.currentTimeMillis());
        String sResult = result.getStatus().getValue();
        String s = StringUtils.rightPad(result.getRelativePath().toString(), CommonConstants.OUTPUT_LENGTH, ".");
        if (result.getEndTime() != null) {
            Double duration = (double) (result.getEndTime() - result.getStartTime()) / 1000;
            getLog().info(s + " " + sResult + " [  " + duration + " s]");
        }
        return result;
    }

    void logResultSummary(List<ApiResult> results) {
        if (results.size() == 0) {
            return;
        }
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
        ApiResult result = results.get(0);
        Double totalTime = (double) (System.currentTimeMillis() - result.getStartTime()) / 1000;

        getLog().info("Total Files: " + results.size());
        getLog().info("Total time: " + totalTime + " s");

        DateFormat df = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
        Date date = new Date();

        getLog().info("Finished at: " + df.format(date));
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
    }
}