package com.gs.cft.contracts.generator;

public class CommonConstants {
    public static final String PROJECT_ROOT_DIR = "contract-store";
    public static final int OUTPUT_LENGTH = 80;

    public static final String B2B = ".b2b";
    public static final String YAML = ".yaml";
    public static final String AVRO = ".avro";
    public static final String WIP = "wip-";
    public static final String SERVER_REPLACE_TEXT = "SERVER-NODE";
}
