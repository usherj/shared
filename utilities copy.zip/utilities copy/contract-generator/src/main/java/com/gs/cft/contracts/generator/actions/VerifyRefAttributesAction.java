package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;

import java.io.IOException;
import java.nio.file.Files;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VerifyRefAttributesAction implements Action {
    private static String key = "$ref:";
    private static String key2 = "- " + key;

    public static ApiResult execute(ApiResult result) {
        if (!result.isVersionMatch()) {
            return result;
        }

        String[] lines;
        try {
            lines = Files.lines(result.getSourcePath()).toArray(String[]::new);
        } catch (IOException ex) {
            throw new RuntimeException(String.format("Error: File NOT found %s", result.getSourcePath()));
        }

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.contains(key) && !line.contains(key2)) {
                int prevLineLen = countBeginingSpaces(lines[i - 1]);
                int lineLen = countBeginingSpaces(line);
                int nextLineLen = 0;
                if (i + 1 < lines.length) {
                    nextLineLen = countBeginingSpaces(lines[i + 1]);
                }
                if (lineLen != 0 && (lineLen == prevLineLen || lineLen == nextLineLen)) {
                    throw new RuntimeException(String.format("Error: Attribute found at same level as $ref Line[%s]: %s", i + 1, line));
                }
            }
        }


        return result;
    }

    private static int countBeginingSpaces(String s) {
        if (s.replaceAll(" ", "").startsWith("#")) {
            return 0;
        }
        Pattern p = Pattern.compile("([^\\s]+)?(\\s)+");
        final Matcher matcher = p.matcher(s);
        if (!matcher.find()) {
            return s.length();
        }
        return matcher.end();
    }
}
