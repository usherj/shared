package com.gs.cft.contracts.generator.mojos;

import com.gs.cft.contracts.generator.CommonConstants;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.v3.parser.core.models.SwaggerParseResult;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class OpenAPIFactory {
    private static final Logger log = LoggerFactory.getLogger(CopyMojo.class);

    public static List<Path> getContractPaths(Path directoryPath, String[] includes, String[] excludes) {
        File directory = directoryPath.toFile();
        if (!directory.exists() || !directory.isDirectory()) {
            throw new RuntimeException("Contract directory is not a valid directory: " + directoryPath);
        }

        Collection<File> files = FileUtils.listFiles(
                directory,
                new RegexFileFilter(".*\\" + CommonConstants.YAML),
                TrueFileFilter.TRUE);

        return files.stream()
                .filter(file -> !filterMatch(file, excludes))
                .filter(file -> filterMatch(file, includes))
                .map(file -> file.toPath())
                .sorted(Comparator.comparing(Path::getFileName))
                .collect(Collectors.toList());
    }

    public static Path getRelativePath(Path path) {
        String parentProjectName = CommonConstants.PROJECT_ROOT_DIR;
        int pos = path.toString().indexOf(parentProjectName) + parentProjectName.length();
        if (pos <= 0) {
            return path;
        }

        String sPath = path.toString().substring(pos);
        return Paths.get(sPath);
    }

    public static String writeString(String string, Path path) {
        File file = path.toFile();
        if (file.exists()) {
            file.delete(); // remove if already exists
        }
        try {
            FileUtils.writeStringToFile(path.toFile(), string);
        }
        catch (Exception e) {
            log.error("Could NOT write: " + path);
            e.printStackTrace();
        }
        return string;
    }

    public static String getFileName(File file, String version) {
        String fileName = file.toPath().getFileName().toString();
        fileName = fileName.replace(CommonConstants.YAML, "");
        if (version == null) {
            fileName = fileName + CommonConstants.YAML;
        } else {
            fileName = fileName + "." + version + CommonConstants.YAML;
        }

        return fileName;
    }

    protected static boolean filterMatch(File file, String[] filters) {
        if (filters == null || filters.length == 0) {
            return true;
        }
        Path path = file.toPath();
        for (String filter:filters) {
            filter = filter.replace("*", ".*");
            if (File.separator.equals("\\")) { // Windows needs 2 separators for regex.
                filter = filter.replace(File.separator, File.separator + File.separator);
            }
            if (path.toString().matches(filter)) {
                return true;
            }
        }
        return false;
    }

    public static OpenAPI getOpenAPI(String contractFilePath) {
        ParseOptions parseOptions = new ParseOptions();
        parseOptions.setResolve(true);

        SwaggerParseResult swaggerParseResult = new OpenAPIV3Parser().readLocation(contractFilePath, null, parseOptions);
        if (swaggerParseResult.getOpenAPI() == null) {
            throw new RuntimeException("Unable to getResults the OpenAPI file: " + swaggerParseResult.getMessages().toString());
        }

        return swaggerParseResult.getOpenAPI();
    }

    public static List<Operation> getOperations(PathItem pathItem) {
        if (pathItem == null) {
            return null;
        }
        List<Operation> operations = new ArrayList<>();

        if (pathItem.getGet()!= null) {
            operations.add(pathItem.getGet());
        }
        if (pathItem.getPost()!= null) {
            operations.add(pathItem.getPost());
        }
        if (pathItem.getPut()!= null) {
            operations.add(pathItem.getPut());
        }
        if (pathItem.getDelete()!= null) {
            operations.add(pathItem.getDelete());
        }
        if (pathItem.getPatch()!= null) {
            operations.add(pathItem.getPatch());
        }

        return operations;
    }

    protected static RuntimeException getErrorException(String fileName, String message) {
        return new RuntimeException("Error with contract in file " + fileName + ": " + message);
    }
}
