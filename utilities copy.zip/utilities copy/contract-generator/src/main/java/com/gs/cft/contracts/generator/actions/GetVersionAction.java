package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.CommonConstants;
import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.CopyMojo;
import io.swagger.v3.oas.models.OpenAPI;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;
import java.util.regex.Pattern;

public class GetVersionAction implements Action {
    private static final Logger log = LoggerFactory.getLogger(CopyMojo.class);
    private static final Pattern VERSION_PATTERN = Pattern.compile("^.*v[0-9].*$");
    private static final Pattern VERSION_PATTERN_MULTI = Pattern.compile("^.*[0-9]\\.[0-9]\\.[0-9].*$");

    public static ApiResult execute(ApiResult result) {
        String infoVersion = getVersionContract(result.getApi());
        String fileNameVersion = getVersionFilename(result.getFilename());

        if (infoVersion == null && fileNameVersion == null) {
            result.setVersion("v1");
            return result; // just can't do anything
        }

        String version = infoVersion;
        if (infoVersion == null && fileNameVersion != null) {
            version = fileNameVersion;
        }
        result.setVersion(version);

        if (!infoVersion.equalsIgnoreCase(fileNameVersion)) {
// Have mismatch
            if (result.isVersionMatch()) {
                throw getErrorException(result.getRelativePath().toString(), "File version and Info.version are not equal: ");
            } else {
                if (fileNameVersion != null) {
                    log.warn("File version and Info.version are not equal: " + result.getRelativePath().toString());
                }
            }
        }

        if (result.isVersionMatch()) {
            setPathVersions(result);
        }

        return result;
    }

    private static ApiResult setPathVersions (ApiResult result) {
        io.swagger.v3.oas.models.Paths paths = new io.swagger.v3.oas.models.Paths();

        Set<String> keySet = result.getApi().getPaths().keySet();
        for(String path : keySet) {
            String pathVersion = getVersionPath(path);
            if (pathVersion == null) {
                String newPath = "/" + result.getVersion() + path;
                paths.addPathItem(newPath, result.getApi().getPaths().get(path));
//                getLog().info("Need to add version to path: " + newPath);
            } else {
                if (!result.getApi().getInfo().getVersion().equalsIgnoreCase(pathVersion)) {
                    throw getErrorException(result.getRelativePath().toString(), "Path found DOES NOT match version. Path: " + path + " Expected version: " + result.getVersion());
                }
                paths.addPathItem(path, result.getApi().getPaths().get(path));
            }
        }
        result.getApi().setPaths(paths);
        return result;
    }

    private static String getVersionContract (OpenAPI api) {
        if (api.getInfo() == null || api.getInfo().getVersion() == null) {
            return null;
        }
        return getVersion(api.getInfo().getVersion());
    }

    public static String getVersionFilename (String search) {
        if (search.contains(".")) {
            search = StringUtils.substringAfter(search,".")
                    .replace(CommonConstants.B2B, "")
                    .replace(CommonConstants.AVRO, "")
                    .replace(CommonConstants.YAML, "");
        }
        return getVersion(search);
    }

    private static String getVersionPath (String search) {
        int pos = search.indexOf("/", 1);
        if (pos > 0) {
            search = search.substring(1, pos);
        }
        return getVersion(search);
    }

    private static String getVersion (String search) {
        if (VERSION_PATTERN.matcher(search).find()) {
            return search;
        }
        if (VERSION_PATTERN_MULTI.matcher(search).find()) {
            return String.format("v%s", StringUtils.substringBefore(search, "."));
        }
        return null;
    }

    static RuntimeException getErrorException(String fileName, String message) {
        return new RuntimeException("Error with contract in file " + fileName + ": " + message);
    }
}
