package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.CommonConstants;
import com.gs.cft.contracts.generator.models.ApiResult;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ServersUpdateAction implements Action {

    public static ApiResult execute(ApiResult result, OpenAPI apiTemplateAuth, OpenAPI apiTemplateAgentAuth, boolean includeServers, boolean applyGatewayChanges) {
        if (!includeServers && applyGatewayChanges) {
            return result;
        }

        OpenAPI api = result.getApi();
        String serverName = getServerName(api);
        if (serverName == null) { // If No server found, do no merge
            return result;
        }

        OpenAPI templateApi = apiTemplateAuth;
        if (result.getRelativePath().toString().toLowerCase().contains("agent")) {
            templateApi = apiTemplateAgentAuth;
        }

//Replace server list in source file
        Server templateServer = templateApi.getServers().get(0);
        String templateServerName = templateServer.getUrl().replace(CommonConstants.SERVER_REPLACE_TEXT, serverName);

        List<Server> servers = new ArrayList<>();
        Server server = new Server();
        server.setUrl(templateServerName);
        server.setVariables(templateServer.getVariables());
        servers.add(server);
        api.setServers(servers);

        return result;
    }

    private static String getServerName(OpenAPI api) {
//Check to see if have valid server entry
        Optional<Server> first = api.getServers().stream()
                .filter(s -> !s.getUrl().toString().equalsIgnoreCase("/"))
                .findFirst();

        if (!first.isPresent()) {
//None found
            return null;
        }

        String server = first.get().getUrl();

        int pos = server.indexOf(".");
        if (pos > 0) {
            server = server.substring(pos + 1);
        }
        return server.toLowerCase()
                .replace("https", "")
                .replace("http", "")
                .replace(":", "")
                .replace("//", "")
                .replace(File.separator, "")
                .replace(".cft", "")
                .replace(".site", "")
                .replace(".gs.com", "")
                .replace("dev.", "")
                .replace("qa.", "")
                .replace("fwqa.", "")
                .replace("uat.", "")
                .replace("training.", "");
    }
}
