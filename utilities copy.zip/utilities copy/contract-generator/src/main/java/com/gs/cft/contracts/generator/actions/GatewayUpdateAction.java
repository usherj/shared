package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.OpenAPIFactory;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityScheme;

import java.util.List;
import java.util.Map;

public class GatewayUpdateAction implements Action {

    public static ApiResult execute(ApiResult result, OpenAPI apiTemplateGateway, boolean applyGatewayChanges) {
        if (!applyGatewayChanges) {
            return result;
        }

        OpenAPI api = result.getApi();

        if (api.getInfo() == null || api.getInfo().getTitle() == null) {
            throw new RuntimeException(String.format(
                    "Error: Attempting to apply gateway update to contract without Info or Info.Title sections for %s", result.getRelativePath()));
        }

//Set Info section
        Info info = apiTemplateGateway.getInfo();
        api.getInfo().setContact(info.getContact());
        api.getInfo().setLicense(info.getLicense());
        api.getInfo().setTermsOfService(info.getTermsOfService());

//set External docs
        api.setExternalDocs(apiTemplateGateway.getExternalDocs());

// Set Parameters based on config
        List<io.swagger.v3.oas.models.parameters.Parameter> parameters = apiTemplateGateway.getPaths().get("/template").getGet().getParameters();

        api.getPaths().values().forEach(pathItem -> {
            List<Operation> operations = OpenAPIFactory.getOperations(pathItem);
            operations.forEach(operation -> {
                parameters.forEach(parameter -> {
                    operation.addParametersItem(parameter);
                });
            });
        });

// Set global security based on config
        api.setSecurity(apiTemplateGateway.getSecurity());

// Set global security based on config
        api.setServers(apiTemplateGateway.getServers());

// Set Security Schemes based on config
        Map<String, SecurityScheme> securitySchemes = apiTemplateGateway.getComponents().getSecuritySchemes();
        api.getComponents().setSecuritySchemes(securitySchemes);

        return result;
    }

}
