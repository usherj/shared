package com.gs.cft.contracts.generator.models;

import com.gs.cft.contracts.generator.models.Status;
import io.swagger.v3.oas.models.OpenAPI;

import java.nio.file.Path;

public class ApiResult {

    Path sourcePath;

    Path relativePath;
    String filename;
    String version;
    boolean isVersionMatch;

    OpenAPI api;
    Long startTime;

    Long endTime;
    Status status = Status.SUCCESS;

    public ApiResult(Path sourcePath) {
        this.sourcePath = sourcePath;
    }

    public Path getSourcePath() {
        return sourcePath;
    }

    public void setSourcePath(Path sourcePath) {
        this.sourcePath = sourcePath;
    }

    public OpenAPI getApi() {
        return api;
    }

    public void setApi(OpenAPI api) {
        this.api = api;
    }

    public Path getRelativePath() {
        return relativePath;
    }

    public void setRelativePath(Path relativePath) {
        this.relativePath = relativePath;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public boolean isVersionMatch() {
        return isVersionMatch;
    }

    public void setVersionMatch(boolean versionMatch) {
        isVersionMatch = versionMatch;
    }
}
