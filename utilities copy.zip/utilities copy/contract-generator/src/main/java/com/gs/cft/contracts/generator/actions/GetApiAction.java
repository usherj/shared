package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.models.Status;
import com.gs.cft.contracts.generator.mojos.CopyMojo;
import io.swagger.v3.parser.OpenAPIV3Parser;
import io.swagger.v3.parser.core.models.ParseOptions;
import io.swagger.v3.parser.core.models.SwaggerParseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class GetApiAction implements Action {
    private static final Logger log = LoggerFactory.getLogger(CopyMojo.class);

    public static ApiResult execute(ApiResult result) {
        String contractFilePath = result.getSourcePath().toString();
        ParseOptions parseOptions = new ParseOptions();
        parseOptions.setResolve(true);

        SwaggerParseResult apiResult = new OpenAPIV3Parser().readLocation(contractFilePath, null, parseOptions);

        List<String> messages = apiResult.getMessages();
        for (String message:messages) {
            processMessage(message, result);
        }

        if (result.getStatus().equals(Status.ERROR)) {
            throw new RuntimeException("Error found in contract: " + result.getRelativePath());
        }
        if (apiResult.getOpenAPI() == null) {
            throw new RuntimeException("Unable to getResults the OpenAPI file: " + result.getRelativePath());
        }

        result.setApi(apiResult.getOpenAPI());

        return result;
    }

    private static void processMessage (String message, ApiResult result) {
        result.setStatus(Status.WARNING); // Have at least one message

        String[] errorKeys = new String[] {
//                "already exists",
                "is missing",
                "operationId is repeated",
                "Unable",
                "Could not find"
        };

        for (String s:errorKeys) { //check if the message contains any of the key phrases
            if (message.toLowerCase().contains(s.toLowerCase())) {
                result.setStatus(Status.ERROR);
            }
        }
        log.warn(message);
        if (result.getStatus().equals(Status.ERROR)) {
            throw new RuntimeException("Error found in contract: " + result.getRelativePath());
        }
    }
}
