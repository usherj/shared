package com.gs.cft.contracts.generator.actions;

import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator;
import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.CopyMojo;
import io.swagger.v3.core.util.Yaml;
import io.swagger.v3.oas.models.OpenAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Paths;

import static com.gs.cft.contracts.generator.mojos.OpenAPIFactory.writeString;

public class WriteAction implements Action {
    private static final Logger log = LoggerFactory.getLogger(CopyMojo.class);

    public static ApiResult execute(ApiResult result, boolean flattenDirectoryStrucure, String targetDirectory) {
//Get TargetPath
        String fileName = targetDirectory + result.getRelativePath();
        if (flattenDirectoryStrucure) {
            fileName = targetDirectory + File.separator + result.getFilename();
        }

        OpenAPI api = result.getApi();
        String yaml = "";
        try {
            // (Optional) Configure YAML formatter
            YAMLFactory factory = (YAMLFactory) Yaml.mapper().getFactory();
            factory.disable(YAMLGenerator.Feature.WRITE_DOC_START_MARKER)
                    .enable(YAMLGenerator.Feature.MINIMIZE_QUOTES)
                    .enable(YAMLGenerator.Feature.ALWAYS_QUOTE_NUMBERS_AS_STRINGS);

            yaml = Yaml.pretty().writeValueAsString(api);
        } catch (Exception e) {
            log.error("Could NOT get Pretty Yaml: " + result.getRelativePath());
            e.printStackTrace();
        }

        writeString(yaml, Paths.get(fileName));
        return result;
    }
}
