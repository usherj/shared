package com.gs.cft.contracts.generator.mojos;

import com.gs.cft.contracts.generator.CommonConstants;
import com.gs.cft.contracts.generator.actions.*;
import com.gs.cft.contracts.generator.models.ApiResult;
import io.swagger.v3.oas.models.OpenAPI;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.annotation.ThreadSafe;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.gs.cft.contracts.generator.mojos.OpenAPIFactory.getContractPaths;
import static com.gs.cft.contracts.generator.mojos.OpenAPIFactory.getRelativePath;

/**
 * scans the source directory, updates gen contract - enriching servers:, copies contract to target (overwrite).
 * Primarily is used to support ui package - by using generated contract ui defincincy of multiple levels
 * of references are overcome. If future version of ui overcomes this problem, this plugin can be removed.
 */

@ThreadSafe
@Mojo(name = "copy", defaultPhase = LifecyclePhase.GENERATE_SOURCES)
public class CopyMojo extends AbstractApiGenMojo {

    private Map<String, String> duplicates = new HashMap<>();
    OpenAPI templateApiStandard;
    OpenAPI templateApiGateway;
    OpenAPI templateApiAgentAuth;
    OpenAPI templateApiAuth;

    @Parameter(required = false, defaultValue = "false")
    private boolean replaceTargetDirectory = false;

    @Parameter(required = false, defaultValue = "false")
    private boolean flattenDirectoryStrucure = false;

    @Parameter(required = false, defaultValue = "false")
    private boolean includeServers = false;

    @Parameter(required = false, defaultValue = "false")
    private boolean applyGatewayChanges = false;

    @Parameter(required = false)
    String[] versionValidationIncludes = new String[] {
            "*/contracts/*",
            "*/agent-contracts/*"
    };

    @Parameter(required = false)
    private String templateStandardFilename = "/shared-components/templates/standard-mods.yaml";

    @Parameter(required = false)
    private String templateGatewayFilename = "/shared-components/templates/gateway-mods.yaml";

    @Parameter(required = false)
    private String templateAgentAuthFilename = "/shared-components/templates/servers-proxyagentauth.yaml";

    @Parameter(required = false)
    private String templateAuthFilename = "/shared-components/templates/servers-proxyauth.yaml";

    public CopyMojo() {
    }

    public static void main(String[] args) throws MojoExecutionException {
        CopyMojo mojo = new CopyMojo();

        String baseDir = "/Users/usherj/APICode/contract-store";
        if (!File.separator.equalsIgnoreCase("/")) {
            baseDir = "h:/APICode/contract-store";
        }
        mojo.replaceTargetDirectory = true;
//        mojo.excludes = new String[] {
//                "*/shared-components/*",
//                "*/shared/*",
//                "*/web-ui/*",
//                "*/uk-contracts/*",
//                "*/.idea/*",
//                "*pom*",
//                "*/bundle-builds/*",
//                "*/templates/*",
//                "*/target/*",
//                "*avro*"
//        };

        String buildDir = "";
//Contracts config
        buildDir = "/contracts";
        mojo.contractsDirectory = baseDir + buildDir;
        mojo.targetDirectory = baseDir + buildDir + "/target/classes";
        mojo.flattenDirectoryStrucure = true;
        mojo.applyGatewayChanges = false;
        mojo.includeServers = false;
//        mojo.includes = new String[]{
//            "*/accounts-checks.v1.b2b.yaml"
//        };
//                "*/core-banking-adapter.v1.yaml"
//            "*/accounts-test.v1.b2b.yaml"
//            "*/parties/parties-persons.v1.b2b.yaml",
//            "*/deposits/kba.yaml",
//            "*/deposits/savings-management.yaml",
//            "*/deposits/customer-activity-log.yaml",
//            "*/corebanking/corebanking.yaml",
//            "*/deposits/roles-agent.yaml",
//            "*/agent/agent-chat.yaml",
//            "*/common/documents.yaml",
//            "*/deposits/savings-processing.yaml",
//            "*/deposits/promotion-management.yaml",
//            "*/deposits/rates.yaml",
//            "*/deposits/bank-account-verification.yaml",
//            "*/common/authentication.yaml",
//            "*/common/identity.yaml",
//            "*/lending/loan-processing.yaml",
//            "*/common/profile.yaml",
//            "*/agent/agent-ivr.yaml",
//            "*/common/communications.yaml",
//            "*/common/personro.yaml"
//        };

        mojo.excludes = new String[] {
            "*/target/*",
            "*wip*"
        };

//Gateway Cloud config
//        buildDir = "/bundle-builds/gateway-cloud-bundle";
//        mojo.contractsDirectory = baseDir + buildDir + "/../../contracts";
//        mojo.targetDirectory = baseDir + buildDir + "/target/classes";
//        mojo.flattenDirectoryStrucure = true;
//        mojo.gatewayUpdates = true;
//        mojo.includes = new String[]{"*/accounts/*"};

//Build Artifacts config
//        buildDir = "/bundle-builds/build-artifacts";
//        mojo.contractsDirectory = baseDir + buildDir + "/../../contracts";
//        mojo.targetDirectory = baseDir + buildDir + "/target/classes";
//        mojo.flattenDirectoryStrucure = true;

//WebUI config
//        buildDir = "/web-ui";
//        mojo.contractsDirectory = baseDir + buildDir + "/..";
//        mojo.targetDirectory = baseDir + buildDir + "/target/classes";
//        mojo.flattenDirectoryStrucure = false;
//        mojo.gatewayUpdates = false;
//        mojo.includeServers = true;
//        mojo.excludes = new String[] {
//                "*wip*",
//                "*/target/*",
//                "*/web-ui/*",
//                "*/templates/*",
//                "*/.m2/*",
//                "*/shared-components/*",
//                "*/shared/*",
//                "*/.idea/*"
//        };

//Legacy-build config
//        buildDir = "/legacy-contracts";
//        mojo.contractsDirectory = baseDir + buildDir;
//        mojo.targetDirectory = baseDir + buildDir + "/target/classes";
//        mojo.flattenDirectoryStrucure = true;
//        mojo.excludes = new String[] {
//                "*/target/*",
//                "*wip*",
//                "*avro*"
//        };

        mojo.execute();
    }

    public void execute() {
        setup();

        Path contractPath = projectBaseDirectory.resolve(contractsDirectory);
        List<ApiResult> results = getContractPaths(contractPath, includes, excludes).stream()
                .map(path -> createResult(path))
                .map(result -> GetApiAction.execute(result))
                .map(result -> GetVersionAction.execute(result))
                .map(result -> actionDuplicateCheck(result))
                .map(result -> VerifyPathsAction.execute(result))
                .map(result -> VerifyRefAttributesAction.execute(result))
                .map(result -> ScanObjectPropertiesAction.execute(result))
                .map(result -> UpdateAction.execute(result, templateApiStandard))
                .map(result -> ServersUpdateAction.execute(result, templateApiAuth, templateApiAgentAuth, includeServers, applyGatewayChanges))
                .map(result -> GatewayUpdateAction.execute(result, templateApiGateway, applyGatewayChanges))
                .map(result -> WriteAction.execute(result, flattenDirectoryStrucure, targetDirectory))
                .map(result -> logResult(result))
                .collect(Collectors.toList());

        logResultSummary(results);
    }

    private void setup() {
        for (int i = 0; i < versionValidationIncludes.length; i++) {
            versionValidationIncludes[i] = versionValidationIncludes[i].replace("\\", "/").replace("/", File.separator);
        }

        super.setParams();
        logHeader("copy");

        getLog().info("targetDirectory: " + targetDirectory);
        getLog().info("replaceTargetDirectory: " + replaceTargetDirectory);
        getLog().info("flattenDirectoryStrucure: " + flattenDirectoryStrucure);
        getLog().info("includeServers: " + includeServers);
        getLog().info("applyGatewayChanges: " + applyGatewayChanges);

        if (includeServers) {
            getLog().info("templateAuthFilename: " + templateAuthFilename);
            getLog().info("templateAgentAuthFilename: " + templateAgentAuthFilename);
        }

//preload template apis
        templateApiStandard = OpenAPIFactory.getOpenAPI(this.projectBaseDirectory + this.templateStandardFilename);
        templateApiGateway = OpenAPIFactory.getOpenAPI(this.projectBaseDirectory + this.templateGatewayFilename);
        templateApiAgentAuth = OpenAPIFactory.getOpenAPI(this.projectBaseDirectory + this.templateAgentAuthFilename);
        templateApiAuth = OpenAPIFactory.getOpenAPI(this.projectBaseDirectory + this.templateAuthFilename);

        super.logFilterParams();

        //Remove target directory if exists
        if (replaceTargetDirectory) {
            File file = new File(targetDirectory);
            if (file.exists()) {
                try {
                    FileUtils.deleteDirectory(file);
                } catch (IOException ex) {
                    getLog().warn("Could not delete Target directory: " + targetDirectory);
                }
            }
        }
    }

    private ApiResult createResult(Path path) {
        ApiResult result = new ApiResult(path);

        File file = path.toFile();
        result.setRelativePath(getRelativePath(file.toPath()));
        result.setStartTime(System.currentTimeMillis());
        result.setFilename(file.toPath().getFileName().toString());

        String s = StringUtils.rightPad(result.getRelativePath().toString(), CommonConstants.OUTPUT_LENGTH, ".");
        getLog().info(s + " READ");

        result.setVersionMatch(OpenAPIFactory.filterMatch(result.getSourcePath().toFile(), versionValidationIncludes));

        return result;
    }

    private ApiResult actionDuplicateCheck(ApiResult result) {
        String fileName = result.getFilename();
        String relativePath = result.getRelativePath().toString();
        if (duplicates.containsKey(fileName)) {
            throw new RuntimeException(String.format("Error: Multiple contracts exist for %s", relativePath));
        }
        duplicates.put(fileName, relativePath);
        return result;
    }
}
