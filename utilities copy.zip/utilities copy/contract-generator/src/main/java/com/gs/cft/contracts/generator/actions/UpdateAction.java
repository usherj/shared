package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.OpenAPIFactory;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.headers.Header;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.responses.ApiResponses;

import java.util.List;
import java.util.Map;

public class UpdateAction implements Action {

    public static ApiResult execute(ApiResult result, OpenAPI apiTemplate) {
        if (!result.isVersionMatch()) {
            return result;
        }

        OpenAPI api = result.getApi();

//Set Info section
        Info info = apiTemplate.getInfo();
        api.getInfo().setContact(info.getContact());
        api.getInfo().setLicense(info.getLicense());
        api.getInfo().setTermsOfService(info.getTermsOfService());

//set External docs
        api.setExternalDocs(apiTemplate.getExternalDocs());

//set Security Schemes
        if (api.getComponents().getSecuritySchemes() == null) { //if provided, keep - if non provide from template.
            api.getComponents().setSecuritySchemes(apiTemplate.getComponents().getSecuritySchemes());
        }

//get path parameters & responses
        String pathKey = "/template";
        List<io.swagger.v3.oas.models.parameters.Parameter> parameters = apiTemplate.getPaths().get(pathKey).getGet().getParameters();
        ApiResponses responses = apiTemplate.getPaths().get(pathKey).getGet().getResponses();

//Add template Headers
        Map<String, Header> headers = api.getComponents().getHeaders();
        Map<String, Header> tHeaders = apiTemplate.getComponents().getHeaders();
        if (headers == null) {
            api.getComponents().setHeaders(tHeaders);
        } else {
            for (String key : tHeaders.keySet()) {
                if (!headers.containsKey(key)) {
                    api.getComponents().getHeaders().put(key, tHeaders.get(key));
                }
            };
        }

//Add template Components.schemas
        Map<String, Schema> schemas = api.getComponents().getSchemas();
        Map<String, Schema> tSchemas = apiTemplate.getComponents().getSchemas();
        if (schemas == null) {
            api.getComponents().setSchemas(tSchemas);
        } else {
            for (String key : tSchemas.keySet()) {
                if (!schemas.containsKey(key)) {
                    schemas.put(key, tSchemas.get(key));
                }
            };
        }

//Set Path parameters
        setPathParamsResponses(result, parameters, responses);

        return result;
    }

    private static ApiResult setPathParamsResponses (ApiResult result, List<io.swagger.v3.oas.models.parameters.Parameter> templateParameters, ApiResponses templateResponses) {
        io.swagger.v3.oas.models.Paths paths = result.getApi().getPaths();
        for (String key : paths.keySet()) {
            PathItem pathItem = paths.get(key);

            List<Operation> operations = OpenAPIFactory.getOperations(pathItem);
            operations.forEach(operation -> {
//Add param if does not exist
                templateParameters.forEach(parameter -> {
                    if (operation.getParameters() == null || !operation.getParameters().contains(parameter)) {
                        operation.addParametersItem(parameter);
                    }
                });
//Add response if does not exist
                for (String response : templateResponses.keySet()) {
                    if (!operation.getResponses().containsKey(response)) {
                        operation.getResponses().addApiResponse(response, templateResponses.get(response));
                    }
                }
            });
        };

        return result;
    }
}
