package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;

public interface Action {
    public static ApiResult execute (ApiResult result) {
        return result;
    }
}
