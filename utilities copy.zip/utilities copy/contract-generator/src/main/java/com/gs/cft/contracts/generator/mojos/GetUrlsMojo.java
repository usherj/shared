package com.gs.cft.contracts.generator.mojos;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gs.cft.contracts.generator.CommonConstants;
import com.gs.cft.contracts.generator.actions.GetVersionAction;
import com.gs.cft.contracts.generator.models.Url;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.apache.http.annotation.ThreadSafe;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.LifecyclePhase;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

import javax.inject.Inject;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * scans a directory, builds list of Url's (name, path), gets html file, replaces text with list.
 * Primarily is used to support swagger-ui package - enables drop down of service names.
 */
@ThreadSafe
@Mojo(name = "get-urls", defaultPhase = LifecyclePhase.GENERATE_SOURCES)
public class GetUrlsMojo extends AbstractApiGenMojo {

    @Parameter(required = true)
    private String inputHtml = "/web-ui/src/main/resources/swagger-ui/index-template.html";

    @Parameter(required = true)
    private String outputHtml = "/web-ui/target/classes/swagger-ui/test.html";

    @Parameter(required = false)
    String templateReplaceText = "URL-LIST";

    @Inject
    public GetUrlsMojo() {
    }

    public static void main(String[] args) throws MojoExecutionException {
        GetUrlsMojo plugin = new GetUrlsMojo();
//        plugin.contractsDirectory = "/Users/usherj/APICode/contract-store/contracts";
        plugin.contractsDirectory = "h:\\APICode\\contract-store\\contracts";
        plugin.excludes = new String[] {
                "*/target/*",
                "*/.idea/*",
                "*pom*",
                "*/*-bundle/*",
                "*/templates/*",
                "*avro*",
                "*/web-ui/*",
                "*/shared/*",
                "*/shared-components/*"
        };

        plugin.execute();
    }

    protected void logFilterParams() {
        super.logHeader("get-urls");
        getLog().info("inputHtml: " + inputHtml);
        getLog().info("outputHtml: " + outputHtml);
        super.logFilterParams();
    }

    public void execute() {
        super.setParams();

        this.inputHtml = Paths.get(inputHtml).normalize().toString();
        this.outputHtml = Paths.get(outputHtml).normalize().toString();
        logFilterParams();

        Path contractPath = projectBaseDirectory.resolve(contractsDirectory);
        List<Url> urls = OpenAPIFactory.getContractPaths(contractPath, includes, excludes).stream()
                .map(path -> createUrl(path))
                .sorted(Comparator.comparing(Url::getName))
                .collect(Collectors.toList());

        String newHtml = getNewHtml(inputHtml, urls);
        OpenAPIFactory.writeString(newHtml, Paths.get(projectBaseDirectory + outputHtml));

        getLog().info("Total Urls created: " + urls.size());
        getLog().info(StringUtils.leftPad("", CommonConstants.OUTPUT_LENGTH, "-"));
    }

    private String getNewHtml(String inputHtml, List<Url> urls) {
        String htmlFilename = projectBaseDirectory + inputHtml;
        File file = new File(htmlFilename);
        if (!file.isFile()) {
            getLog().error("inputHtml NOT FOUND!");
            return "";
        }

        String contents = "";
        String jsonUrls = "";
        try {
            contents = new String(Files.readAllBytes(Paths.get(file.toURI())));
            jsonUrls = new ObjectMapper().writeValueAsString(urls);
            jsonUrls = jsonUrls.replace("{", "\n{");
            contents = contents.replaceAll(templateReplaceText, jsonUrls);
        } catch (IOException e) {
            getLog().error("Could NOT read: " + htmlFilename);
        }
        return contents;
    }

    private Url createUrl(Path path) {
        String url = OpenAPIFactory.getRelativePath(path).toString();
        url = url.replace("\\", "/");

        String name = path.getFileName().toString();
        if (name.contains(".")) {
            name = name.substring(0, name.indexOf('.')); // trim off extension if exists
        }

        String version = GetVersionAction.getVersionFilename(path.getFileName().toString());
        if (version != null) {
            name = name + " " + version.toUpperCase();
        }

        if (!name.toLowerCase().endsWith("contract")) {
            name = WordUtils.capitalize(name, '-') + " Contract";
        }


        return new Url(url, name);
    }
}
