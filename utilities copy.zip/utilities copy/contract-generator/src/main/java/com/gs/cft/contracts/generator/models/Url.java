package com.gs.cft.contracts.generator.models;

import org.apache.commons.text.WordUtils;

import java.nio.file.Path;

public class Url {

    String url;
    String name;

    public Url(String url, String name) {
        this.url = url;
        this.name = name;
    }

    public Url(Path path, int startPos) {
        String url = path.toFile().toString().substring(startPos).replace("\\", "/"); // trim off parent dirs & ensure forward slash
        String name = path.getFileName().toString();
        name = name.substring(0, name.indexOf('.')); // trim off extension
        name = WordUtils.capitalize(name, '-') + " Contract";

        this.url = url;
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("name: ").append(toIndentedString(getName()));
        sb.append(", ");
        sb.append("url: ").append(toIndentedString(getUrl()));
        sb.append("\n");
        return sb.toString();
    }

    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}
