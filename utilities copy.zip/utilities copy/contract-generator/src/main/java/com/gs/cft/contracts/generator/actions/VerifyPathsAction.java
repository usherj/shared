package com.gs.cft.contracts.generator.actions;

import com.gs.cft.contracts.generator.models.ApiResult;
import com.gs.cft.contracts.generator.mojos.OpenAPIFactory;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;

import java.util.List;

public class VerifyPathsAction implements Action {

    public static ApiResult execute(ApiResult result) {
        if (result.getFilename().toString().contains("avro") || !result.isVersionMatch()) {
            return result;
        }

        io.swagger.v3.oas.models.Paths paths = result.getApi().getPaths();
        for (String key : paths.keySet()) {
            PathItem pathItem = paths.get(key);

            List<Operation> operations = OpenAPIFactory.getOperations(pathItem);
            operations.forEach(operation -> {
//Check if operationId exists
                if (operation.getOperationId() == null) {
                    throw new RuntimeException(String.format(
                            "Error: Missing operationId on path: %s in file: %s", key, result.getRelativePath()));
                }
//Check if security exists
                if (operation.getSecurity() == null) {
                    throw new RuntimeException(String.format(
                            "Error: Missing 'security:' definition! operationId: %s path: %s, file: %s", operation.getOperationId(), key, result.getRelativePath()));
                }
            });
        };

        return result;
    }
}
