package com.gs.cft.digital.contractdriven.generators.openapi.spring;


import org.openapitools.codegen.CliOption;
import org.openapitools.codegen.CodegenConfig;
import org.openapitools.codegen.SupportingFile;
import org.openapitools.codegen.languages.SpringCodegen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class GsSpringGenerator extends SpringCodegen implements CodegenConfig {

    public static final String OUTPUT_NAME = "outputFile";
    private static final Logger LOGGER = LoggerFactory.getLogger(GsSpringGenerator.class);

    protected String outputFileDir = "src/main/resources/";

    public String getName() {
        return "gs-spring";
    }

    @Override
    public void processOpts() {
        super.processOpts();
        String outputFile = "openapi.yaml";
        if (additionalProperties.containsKey(OUTPUT_NAME)) {
            outputFile = outputFileDir + additionalProperties.get(OUTPUT_NAME).toString();
        } else {
            outputFile = outputFileDir + new File(getInputSpec()).getName();
        }
        supportingFiles.add(new SupportingFile("openapi.mustache", outputFile));
//    additionalProperties.put("useSpringfox", false);
//    supportingFiles.remove(new SupportingFile("openapiDocumentationConfig.mustache",
//            (sourceFolder + File.separator + configPackage).replace(".", java.io.File.separator), "OpenAPIDocumentationConfig.java"));
//    supportingFiles.remove(new SupportingFile("openapi2SpringBoot.mustache",
//            (sourceFolder + File.separator + basePackage).replace(".", java.io.File.separator), "OpenAPI2SpringBoot.java"));
//    supportingFiles.remove(new SupportingFile("RFC3339DateFormat.mustache",
//            (sourceFolder + File.separator + basePackage).replace(".", java.io.File.separator), "RFC3339DateFormat.java"));
//    supportingFiles.remove(new SupportingFile("homeController.mustache",
//            (sourceFolder + File.separator + configPackage).replace(".", java.io.File.separator), "HomeController.java"));
//        String inputSpec = getInputSpec();
//        if (!inputSpec.endsWith("openapi.yaml")) {
//            System.out.println("POST://file: " + inputSpec + " Could be versioned and loaded into DB along with following project attributes.");
//            Map<String, String> attributes = GsSpringUtil.getProjectAttributes(inputSpec);
//            if (attributes.size() == 0) {
//                System.out.println("Error: Could not find project file on path");
//                return;
//            }
//            attributes.forEach((k, v) -> System.out.println(k + ": " + v));
//        }
    }

    /**
     * Returns human-friendly help for the generator.  Provide the consumer with help
     * tips, parameters here
     *
     * @return A string value for the help message
     */
    public String getHelp() {
        return "Generates a gs-spring client library.";
    }

    public GsSpringGenerator() {
        super();

        // set the output folder here
        outputFolder = "generated-code/gs-spring";
        embeddedTemplateDir = templateDir = "gs-spring";

        cliOptions.add(CliOption.newString(OUTPUT_NAME, "Output filename").defaultValue(outputFileDir + "openapi.yaml"));
    }
}