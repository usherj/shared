package com.gs.cft.digital.contractdriven.generators.openapi.spring;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GsSpringUtil {
    public static void main(String[] args) {
        String path = "H:\\Code\\cft-contracts\\contracts\\documents/documents.yaml";
        Map<String, String> attributes = getProjectAttributes(path);
        if (attributes.size() == 0) {
            System.out.println("Error: Could not find project file on path");
        }
        attributes.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    public static Map<String, String> getProjectAttributes(String path) {
        String filePath = findFile(path, ".gs-project.yml");
        if (filePath == null) {
            return null;
        }
        Map<String, String> values = readYaml(filePath);
        return values;
    }

    public static String findFile(String path, String fileName) {
        path = path.replace("\\", "/");
        path = trimFirst(path, "/");
//        fileName = "/Code/cft-contracts/contracts/documents";
        path = trimLast(path, "/");

        do {
            String testPath = path + "/" + fileName;
            File file = new File(testPath);
            if (file.exists()) {
                return testPath;
            }
            path = trimLast(path, "/");
        } while (path.length() > 0);

        return null;
    }

    private static String trimFirst(String string, String str) {
        int pos = string.indexOf(str);
        if (pos > -1) {
            string = string.substring(pos);
        }
        return string;
    }

    private static String trimLast (String string, String str) {
        int pos = string.lastIndexOf(str);
        if (pos > -1) {
            return string.substring(0, pos);
        }
        return "";
    }

    private static Map<String, String> readYaml(String filename) {
        Path path = Paths.get(filename);
        String productGuid = null;
        String producer = null;
        String packageName = null;

        List<String> strings = null;
        Map<String, String> values = new HashMap<>();
        try {
            strings = Files.readAllLines(path);
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (String string : strings) {
            String key = "productGuid: ";
            if (string.contains(key)) {
                productGuid = string.replace(key, "").replace("\"", "").replace("product::", "").trim();
                key = key.replace(": ", "").trim();
                values.put(key, productGuid);
            }
            key = "producer: ";
            if (string.contains(key)) {
                producer = string.replace(key, "").trim();
                key = key.replace(": ", "").trim();
                values.put(key, producer);
            }
            key = "package: ";
            if (string.contains(key)) {
                packageName = string.replace(key, "").trim();
                key = key.replace(": ", "").trim();
                values.put(key, packageName);
            }
        }

        return values;
    }
}
