# OpenAPI Generator - GS OnPrem Java Service 

## Overview
This is a boiler-plate project to help you get started with your own with an OpenAPI specification for GS on-prem Java services using the Spring Boot Framework.

This project is a template and framework to apply your own implementation and business logic for your service.

## About OpenAPI

OpenAPI defines a standard, language-agnostic interface for REST APIs which allows both humans and computers to discover and understand the capabilities of the service without access to source code, documentation, or network traffic inspection.
When properly described with OpenAPI, a consumer can understand and interact with the remote service with a minimal amount of implementation logic. OpenAPI removes the guesswork in calling the service.

Review the [OpenAPI-Spec](https://github.com/OAI/OpenAPI-Specification) for additional information about the OpenAPI project, additional libraries with language support and more.

## Working with the GS Spring openAPI Generators
### Prerequisites
1. Ensure you've generated a client setup that includes the following:

```
.
|- README.md    // this file
|- pom.xml      // build script
|-- src
|--- main
|---- java
|----- com.gs.cft.digital.contractdriven.generators.openapi.spring.GsCloudSpringGenerator.java // generator file
|---- resources
|----- gs-spring // template files
|----- META-INF
|------ services
|------- org.openapitools.codegen.CodegenConfig
```

2. You _will_ need to make changes to the following files:

    * `GsSpringGenerator.java`

    * Templates in this folder:
  `src/main/resources/gs-spring`


3. Once modified, you can run the `mvn package`in your generator project. 


    * A single jar file will be produced in `target`. You can now use that with [OpenAPI Generator](https://openapi-generator.tech):

        * For mac/linux:

        `java -cp /path/to/openapi-generator-cli.jar:/path/to/your.jar org.openapitools.codegen.OpenAPIGenerator generate -g gs-spring -i /path/to/openapi.yaml -o ./test`

        (Do not forget to replace the values `/path/to/openapi-generator-cli.jar`, `/path/to/your.jar` and `/path/to/openapi.yaml` in the previous command)

         * For Windows users, you will need to use `;` instead of `:` in the classpath, e.g.

        `java -cp /path/to/openapi-generator-cli.jar;/path/to/your.jar org.openapitools.codegen.OpenAPIGenerator generate -g gs-spring -i /path/to/openapi.yaml -o ./test`


4. Your templates are now available to the client generator to write output values.

## Modifying the Project

Here are some tips to get started:

1. Review the code comments in `GsSpringGenerator.java`. 
   * See how the `GsSpringGenerator` implements `CodegenConfig`. That class has the signature of all values that can be overridden.

2. Step through the GsSpringGenerator.java in a debugger.  Debug the JUnit
test in DebugCodegenLauncher. That runs the command line tool and lets you inspect what the code is doing.  

3. For the templates themselves, you have a number of values available to you for generation.
You can execute the `java` command from above while passing different debug flags to show
the object you have available during client generation:

```
# The following additional debug options are available for all codegen targets:
# -DdebugOpenAPI prints the OpenAPI Specification as interpreted by the codegen
# -DdebugModels prints models passed to the template engine
# -DdebugOperations prints operations passed to the template engine
# -DdebugSupportingFiles prints additional data passed to the template engine

java -DdebugOperations -cp /path/to/openapi-generator-cli.jar:/path/to/your.jar org.openapitools.codegen.OpenAPIGenerator generate -g gs-spring -i /path/to/openapi.yaml -o ./test
```

The above example outputs the debug info for operations.
You can use this info in the `api.mustache` file.

## Contributing

All are welcome to contribute to this project and should consult with [Daniel Kuras](mailto:Daniel.Kuras@ln.email.gs.com).



