# OpenAPI YAML
This is a OpenAPI YAML built by the [openapi-generator](https://github.com/openapitools/openapi-genreator) project.