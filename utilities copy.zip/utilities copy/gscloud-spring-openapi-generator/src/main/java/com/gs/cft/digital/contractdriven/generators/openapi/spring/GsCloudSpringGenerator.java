package com.gs.cft.digital.contractdriven.generators.openapi.spring;


import io.swagger.v3.oas.models.security.SecurityScheme;
import org.openapitools.codegen.CliOption;
import org.openapitools.codegen.CodegenConfig;
import org.openapitools.codegen.CodegenSecurity;
import org.openapitools.codegen.SupportingFile;
import org.openapitools.codegen.languages.SpringCodegen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;
import java.util.Map;

public class GsCloudSpringGenerator extends SpringCodegen implements CodegenConfig {

    public static final String OUTPUT_NAME = "outputFile";
    private static final Logger LOGGER = LoggerFactory.getLogger(GsCloudSpringGenerator.class);

    protected String outputFileDir = "src/main/resources/";

    public String getName() {
        return "gscloud-spring";
    }

    @Override
    public List<CodegenSecurity> fromSecurity(Map<String, SecurityScheme> securitySchemeMap) {
        return super.fromSecurity(securitySchemeMap);
    }

    @Override
    public Map<String, Object> postProcessOperationsWithModels(Map<String, Object> objs, List<Object> allModels) {
        return super.postProcessOperationsWithModels(objs, allModels);
    }

    @Override
    public void processOpts() {
        super.processOpts();
        String outputFile = "openapi.yaml";
        if (additionalProperties.containsKey(OUTPUT_NAME)) {
            outputFile = outputFileDir + additionalProperties.get(OUTPUT_NAME).toString();
        } else {
            outputFile = outputFileDir + new File(getInputSpec()).getName();
        }
        supportingFiles.add(new SupportingFile("openapi.mustache", outputFile));
        additionalProperties.put("useSpringfox", false);
        supportingFiles.remove(new SupportingFile("openapiDocumentationConfig.mustache",
                (sourceFolder + File.separator + configPackage).replace(".", java.io.File.separator), "OpenAPIDocumentationConfig.java"));
        supportingFiles.remove(new SupportingFile("openapi2SpringBoot.mustache",
                (sourceFolder + File.separator + basePackage).replace(".", java.io.File.separator), "OpenAPI2SpringBoot.java"));
        supportingFiles.remove(new SupportingFile("RFC3339DateFormat.mustache",
                (sourceFolder + File.separator + basePackage).replace(".", java.io.File.separator), "RFC3339DateFormat.java"));
        supportingFiles.remove(new SupportingFile("homeController.mustache",
                (sourceFolder + File.separator + configPackage).replace(".", java.io.File.separator), "HomeController.java"));
//        supportingFiles.remove(new SupportingFile("apiUtil.mustache",
//                (sourceFolder + File.separator + apiPackage).replace(".", java.io.File.separator), "ApiUtil.java"));

        supportingFiles.remove(new SupportingFile("pom.mustache", "", "pom.xml"));
        supportingFiles.remove(new SupportingFile("README.mustache", "", "README.md"));
//        String inputSpec = getInputSpec();
//        if (!inputSpec.endsWith("openapi.yaml")) {
//            System.out.println("POST://file: " + inputSpec + " Could be versioned and loaded into DB along with following project attributes.");
//            Map<String, String> attributes = GsSpringUtil.getProjectAttributes(inputSpec);
//            if (attributes.size() == 0) {
//                System.out.println("Error: Could not find project file on path");
//                return;
//            }
//            attributes.forEach((k, v) -> System.out.println(k + ": " + v));
//        }
    }

    /**
     * Returns human-friendly help for the generator.  Provide the consumer with help
     * tips, parameters here
     *
     * @return A string value for the help message
     */
    public String getHelp() {
        return "Generates a gscloud-spring client library.";
    }


    public GsCloudSpringGenerator() {
        super();
        interfaceOnly = true;

        // set the output folder here
        outputFolder = "generated-code/gscloud-spring";
        embeddedTemplateDir = templateDir = "gscloud-spring";

        cliOptions.add(CliOption.newString(OUTPUT_NAME, "Output filename").defaultValue(outputFileDir + "openapi.yaml"));
        cliOptions.add(CliOption.newBoolean(INTERFACE_ONLY, "Whether to generate only API interface stubs without the server files.", interfaceOnly));
    }
}