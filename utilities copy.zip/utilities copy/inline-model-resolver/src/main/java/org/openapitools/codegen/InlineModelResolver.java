package org.openapitools.codegen;

import io.swagger.v3.oas.models.OpenAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InlineModelResolver {
    static Logger LOGGER = LoggerFactory.getLogger(InlineModelResolver.class);
    void flatten(OpenAPI openapi) {
        LOGGER.info("Models are not flatten");
    }
}
